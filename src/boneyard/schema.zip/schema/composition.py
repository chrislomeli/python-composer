from track import Track
from composition_bar import CompositionBar


class Composition:
    def __init__(self, name, ticks_per_quarter=480):
        self.name = name
        self.ticks_per_quarter = ticks_per_quarter
        self.tracks = {}  # key = track name, value = Track object
        self.composition_bars = []  # List of CompositionBar objects

    def add_track(self, track: Track):
        self.tracks[track.name] = track

    def add_composition_bar(self, comp_bar: CompositionBar):
        self.composition_bars.append(comp_bar)
