from composition_bar import CompositionBar

def render_composition_bar(comp_bar: CompositionBar, ticks_per_unit, bar_start_tick=0):
    midi_events = []
    for vb in comp_bar.voice_bars:
        for note in vb.notes:
            if note.is_rest:
                continue
            start_tick = bar_start_tick + note.start_unit * ticks_per_unit
            duration_tick = note.duration_units * ticks_per_unit
            midi_events.append({
                "time": start_tick,
                "track": vb.track_name,
                "message": f"note_on {note.midi_pitch} vel {note.velocity}"
            })
            midi_events.append({
                "time": start_tick + duration_tick,
                "track": vb.track_name,
                "message": f"note_off {note.midi_pitch}"
            })
    return sorted(midi_events, key=lambda x: x["time"])
