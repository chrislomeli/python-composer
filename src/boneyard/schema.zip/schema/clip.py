from voice_bar import VoiceBar

class Clip:
    def __init__(self, name, track_name, voice_bars=None, metadata=None):
        self.name = name
        self.track_name = track_name
        self.voice_bars = voice_bars or []  # VoiceBars for this clip
        self.metadata = metadata or {}

    def add_voice_bar(self, voice_bar: VoiceBar):
        self.voice_bars.append(voice_bar)
