import librosa

class Note:
    def __init__(self, pitch_name=None, octave=None, duration_units=8,
                 is_rest=False, velocity=90, articulation="normal"):
        self.pitch_name = pitch_name
        self.octave = octave
        self.duration_units = duration_units
        self.is_rest = is_rest
        self.velocity = velocity
        self.articulation = articulation
        self.start_unit = None

    @property
    def midi_pitch(self):
        if self.is_rest or self.pitch_name is None or self.octave is None:
            return None
        note_str = f"{self.pitch_name}{self.octave}"
        return int(librosa.note_to_midi(note_str))
