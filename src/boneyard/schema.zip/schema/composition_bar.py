from typing import List, Optional
from src.schema.voice_bar import VoiceBar

class CompositionBar:
    def __init__(self, composition_bar_index: int,
                 voice_bars: Optional[List[VoiceBar]] = None,
                 metadata: Optional[dict] = None):
        self.bar_index = composition_bar_index
        self.voice_bars: List[VoiceBar] = voice_bars or []
        self.metadata: dict = metadata or {}

    def add_voice_bar(self, voice_bar: VoiceBar) -> None:
        self.voice_bars.append(voice_bar)

