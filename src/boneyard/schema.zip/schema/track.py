
class Track:
    def __init__(self, name, instrument=None, channel=0):
        self.name = name
        self.instrument = instrument
        self.channel = channel
        self.clips = []  # List of Clip objects

    def add_clip(self, clip):
        self.clips.append(clip)
