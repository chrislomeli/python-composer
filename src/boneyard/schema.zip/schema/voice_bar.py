from src.schema.note import Note

class VoiceBar:
    def __init__(self, clip_id, track_name, notes=None, metadata=None):
        self.clip_id = clip_id
        self.track_name = track_name  # Which instrument/track
        self.notes = notes or []      # List of Note objects
        self.metadata = metadata or {}

    def add_note(self, note: Note):
        self.notes.append(note)

